﻿using System;

namespace Madlib
{
    class Program
    {
        static void Main()
        {

            //declare variables
            string Creature;
            string Luminous;
            string Ghastly;
            string Spectral;
            string Countryman;
            string Farrier;
            string Farmer;
            string Dreadful;
            string Apparition;
            string Hound;
            string Story;
            string verb;
            string Body;
            string pluralNoun;
            string noun;

            //write header and instructions
            Console.WriteLine("-------");
            Console.WriteLine("Madlib!");
            Console.WriteLine("-------");

            //ask player to enter words
            Console.Write("Please enter a adjective: ");
            Creature = Console.ReadLine();

            Console.Write("Please enter an adjective: ");
            Luminous = Console.ReadLine();

            Console.Write("Please enter an Type of bird: ");
            Ghastly = Console.ReadLine();

            Console.Write("Please enter an room in a house: ");
            Spectral = Console.ReadLine();

            Console.Write("Please enter an Verb(Past tense): ");
            Countryman = Console.ReadLine();

            Console.Write("Please enter an Verb: ");
            Farrier = Console.ReadLine();

            Console.Write("Please enter an relatives name: ");
            Farmer = Console.ReadLine();

            Console.Write("Please enter an noun : ");
            Dreadful = Console.ReadLine();

            Console.Write("Please enter a a liquid: ");
            Apparition = Console.ReadLine();

            Console.Write("Please enter a verb ending in -ing: ");
            Hound = Console.ReadLine();

            Console.Write("Please enter a part of the body(Plural): ");
            verb = Console.ReadLine();

            Console.Write("Please enter a plural noun: ");
            Body = Console.ReadLine();

            Console.Write("Please enter a verb ending in -ing: ");
            pluralNoun = Console.ReadLine();

            Console.Write("Please enter a noun: ");
            noun = Console.ReadLine();


            //write out story
            Story = "It was a  " + Creature + ", " + "November day. I woke up to the  " +  Luminous + " smell of  " + Ghastly + " roasting in the " + Spectral + " Downstairs. I  " + Countryman + " down the stairs to see if i could help " + Farrier +  " the dinner. My mom said See if  " + Dreadful + " Needs a fresh " + Apparition + " So i carried a tray of glasses full of  " + Hound + " into the " + verb + " room. When i got there, I couldnt believe my "+ Body + " !  There were " +  pluralNoun + "on the " + noun + "!";
            Console.WriteLine(Story);

            //keep window open and prompt for exit
            Console.WriteLine("Press enter to exit");
            Console.ReadKey();
        }
    }
}